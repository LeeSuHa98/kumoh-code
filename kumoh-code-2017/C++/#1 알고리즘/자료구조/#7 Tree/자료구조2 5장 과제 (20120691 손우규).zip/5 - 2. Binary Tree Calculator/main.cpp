#include "Expression.h"

int main()
{
	Expression e;

	e.eval();

	system("pause");

	return 0;
}