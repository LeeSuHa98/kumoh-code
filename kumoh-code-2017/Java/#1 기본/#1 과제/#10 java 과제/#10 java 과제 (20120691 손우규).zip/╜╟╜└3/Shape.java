public abstract class Shape
{
	abstract public double getArea();
}
