package �������;

public class BankApp
{
	public static void main(String[] args)
	{
		Bank bank = new Bank(); // Creates an ATM
		bank.run();		// Runs the ATM
	}
}