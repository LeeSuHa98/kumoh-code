public class Rectangle
{
	public float findArea(int w)
	{
		return (float)(w*w);
	}
	public float findArea(int w, int h)
	{
		return (float)(w*h);
	}
	public double findArea(double w, double h)
	{
		return w*h;
	}
}