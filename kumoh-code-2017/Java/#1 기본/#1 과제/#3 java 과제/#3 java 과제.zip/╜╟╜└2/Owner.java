public class Owner 
{
	private String name;
	private String address;
	private String phone_num;
	
	public Owner()
	{
		name= "0";
		address= "0";
		phone_num= "0";
		
	}

	public String getName()
	{
		return name;
	}
	public String getAddress()
	{
		return address;
	}
	public String getPhoneNum()
	{
		return phone_num;
	}
	
}