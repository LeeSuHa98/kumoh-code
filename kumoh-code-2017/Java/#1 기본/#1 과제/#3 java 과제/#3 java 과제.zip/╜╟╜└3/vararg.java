public class vararg
{
	public int summation(int[] a)
	{
		int total = 0;
		for(int i = 0; i < a.length; i++)
		{
			total += a[i];
		}
		return total;
	}
}
