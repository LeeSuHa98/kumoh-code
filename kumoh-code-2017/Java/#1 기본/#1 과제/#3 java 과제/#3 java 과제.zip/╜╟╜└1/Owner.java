public class Owner
{
	private String name;
	private String address;
	private String phone_num;
	
	public Owner(){}
}